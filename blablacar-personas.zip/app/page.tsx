import BlaBlaCar from "../blablacar-personas"

export default function Home() {
  return <BlaBlaCar />
}

